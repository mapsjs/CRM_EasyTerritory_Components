({

    extendsFrom: 'RecordlistView',
    initialize: function (options) {
        //app.view.invokeParent(this, {type: 'view', name: 'recordlist', method: 'initialize', args:[options]});
        //add listener for custom button
        this._super('initialize', [options]);

        this.context.on('list:ezt_location_lookup_bulk:fire', this.bulk_location_lookup_ezt, this);
    },

    bulk_location_lookup_ezt : function() {
      
       app.alert.show('message-id',{
                        level: 'process',
                        title: 'Location Lookup in progress',
                        
                }); 

       var massCollection = this.context.get("mass_collection");  

       var numOfRecords = massCollection.length;
       var numOfUpdatedRecords = 0;
       var numOfErrors = 0;
       var totalCount = 0;

        var id_array = [];  

        massCollection.each(function(data){     
        
            var obj = {};

            
            app.api.call('update', app.api.buildURL(data.module + '/' + data.id), obj, {       
                success: function(data) {},
                error: function(error) {},
                complete: function() {
                    
                    numOfUpdatedRecords++;

                    app.alert.dismissAll();

                    app.alert.show('message-id', {
                                    level: 'success',
                                    messages: 'Location Lookup Completed! ' + numOfUpdatedRecords + ' records updated.',
                                    autoClose: true

                    });
                    
                },
            })
        

        })

    },


})