<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/Resources/Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */
$mod_strings = array (
  'LBL_TEAM' => 'Teams',
  'LBL_TEAMS' => 'Teams',
  'LBL_TEAM_ID' => 'Team Id',
  'LBL_ASSIGNED_TO_ID' => 'Assigned User Id',
  'LBL_ASSIGNED_TO_NAME' => 'Assigned to',
  'LBL_TAGS_LINK' => 'Tags',
  'LBL_TAGS' => 'Tags',
  'LBL_ID' => 'ID',
  'LBL_DATE_ENTERED' => 'Date Created',
  'LBL_DATE_MODIFIED' => 'Date Modified',
  'LBL_MODIFIED' => 'Modified By',
  'LBL_MODIFIED_ID' => 'Modified By Id',
  'LBL_MODIFIED_NAME' => 'Modified By Name',
  'LBL_CREATED' => 'Created By',
  'LBL_CREATED_ID' => 'Created By Id',
  'LBL_DOC_OWNER' => 'Document Owner',
  'LBL_USER_FAVORITES' => 'Users Who Favorite',
  'LBL_DESCRIPTION' => 'Description',
  'LBL_DELETED' => 'Deleted',
  'LBL_NAME' => 'Name',
  'LBL_CREATED_USER' => 'Created by User',
  'LBL_MODIFIED_USER' => 'Modified by User',
  'LBL_LIST_NAME' => 'Name',
  'LBL_EDIT_BUTTON' => 'Edit',
  'LBL_REMOVE' => 'Remove',
  'LBL_EXPORT_MODIFIED_BY_NAME' => 'Modified By Name',
  'LBL_LIST_FORM_TITLE' => 'EasyTerritory Settings List',
  'LBL_MODULE_NAME' => 'EasyTerritory Settings',
  'LBL_MODULE_TITLE' => 'EasyTerritory Settings',
  'LBL_MODULE_NAME_SINGULAR' => 'EasyTerritory Settings',
  'LBL_HOMEPAGE_TITLE' => 'My EasyTerritory Settings',
  'LNK_NEW_RECORD' => 'Create EasyTerritory Settings',
  'LNK_LIST' => 'View EasyTerritory Settings',
  'LNK_IMPORT_EZTV1_EZTSETTINGS' => 'Import EasyTerritory Settings',
  'LBL_SEARCH_FORM_TITLE' => 'Search EasyTerritory Settings',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'View History',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Activity Stream',
  'LBL_EZTV1_EZTSETTINGS_SUBPANEL_TITLE' => 'EasyTerritory Settings',
  'LBL_NEW_FORM_TITLE' => 'New EasyTerritory Settings',
  'LNK_IMPORT_VCARD' => 'Import EasyTerritory Settings vCard',
  'LBL_IMPORT' => 'Import EasyTerritory Settings',
  'LBL_IMPORT_VCARDTEXT' => 'Automatically create a new EasyTerritory Settings record by importing a vCard from your file system.',
  'LBL_EASYTERRITORYURL' => 'EasyTerritory URL',
  'LBL_EASYTERRITORYPROJECTID' => 'EasyTerritory Project Id',
  'LBL_USERNAME' => 'EasyTerritory User Name',
  'LBL_EASYTERRITORYPASSWORD' => 'EasyTerritory Password (Encrypted)',
  'LBL_LOCATIONLOOKUPSTREETFIELD' => 'Target Module Street Field Name',
  'LBL_LOCATIONLOOKUPCITYFIELD' => 'Target Module City Field Name',
  'LBL_LOCATIONLOOKUPSTATEFIELD' => 'Target Module State Field Name',
  'LBL_LOCATIONLOOKUPZIPFIELD' => 'Target Module Postal Code Field Name',
  'LBL_BINGKEY' => 'Bing Key',
  'LBL_TARGETMODULENAME' => 'Target Module Name',
  'LBL_MODULERELATIONSHIPNAME' => 'Module Relationship Link Name',
);