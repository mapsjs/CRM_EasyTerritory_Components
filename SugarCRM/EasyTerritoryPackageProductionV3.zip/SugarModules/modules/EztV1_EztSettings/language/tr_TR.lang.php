<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/Resources/Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */
$mod_strings = array (
  'LBL_TEAM' => 'Takımlar',
  'LBL_TEAMS' => 'Takımlar',
  'LBL_TEAM_ID' => 'Takım ID',
  'LBL_ASSIGNED_TO_ID' => 'Atanan Kullanıcı ID',
  'LBL_ASSIGNED_TO_NAME' => 'Atanan Kişi',
  'LBL_TAGS_LINK' => 'Etiketler',
  'LBL_TAGS' => 'Etiketler',
  'LBL_ID' => 'KİMLİK',
  'LBL_DATE_ENTERED' => 'Oluşturulma Tarihi',
  'LBL_DATE_MODIFIED' => 'Değiştirilme Tarihi',
  'LBL_MODIFIED' => 'Değiştiren',
  'LBL_MODIFIED_ID' => 'Değiştiren ID',
  'LBL_MODIFIED_NAME' => 'Değiştiren Kişinin İsmi',
  'LBL_CREATED' => 'Oluşturan',
  'LBL_CREATED_ID' => 'Oluşturan ID',
  'LBL_DOC_OWNER' => 'Doküman Sahibi',
  'LBL_USER_FAVORITES' => 'Favori Olan Kullanıcılar',
  'LBL_DESCRIPTION' => 'Tanım',
  'LBL_DELETED' => 'Silindi',
  'LBL_NAME' => 'İsim',
  'LBL_CREATED_USER' => 'Oluşturan Kullanıcı',
  'LBL_MODIFIED_USER' => 'Değiştiren Kullanıcı',
  'LBL_LIST_NAME' => 'İsim',
  'LBL_EDIT_BUTTON' => 'Değiştir',
  'LBL_REMOVE' => 'Sil',
  'LBL_EXPORT_MODIFIED_BY_NAME' => 'Değiştiren Kişinin İsmi',
  'LBL_LIST_FORM_TITLE' => 'EasyTerritory Settings Liste',
  'LBL_MODULE_NAME' => 'EasyTerritory Settings',
  'LBL_MODULE_TITLE' => 'EasyTerritory Settings',
  'LBL_MODULE_NAME_SINGULAR' => 'EasyTerritory Settings',
  'LBL_HOMEPAGE_TITLE' => 'Benim EasyTerritory Settings',
  'LNK_NEW_RECORD' => 'Oluştur EasyTerritory Settings',
  'LNK_LIST' => 'Göster EasyTerritory Settings',
  'LNK_IMPORT_EZTV1_EZTSETTINGS' => 'Import EasyTerritory Settings',
  'LBL_SEARCH_FORM_TITLE' => 'Ara EasyTerritory Settings',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'Tarihçeyi Gör',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Aktiviteler',
  'LBL_EZTV1_EZTSETTINGS_SUBPANEL_TITLE' => 'EasyTerritory Settings',
  'LBL_NEW_FORM_TITLE' => 'Yeni EasyTerritory Settings',
  'LNK_IMPORT_VCARD' => 'Import EasyTerritory Settings vCard',
  'LBL_IMPORT' => 'Import EasyTerritory Settings',
  'LBL_IMPORT_VCARDTEXT' => 'Automatically create a new EasyTerritory Settings record by importing a vCard from your file system.',
  'LBL_EASYTERRITORYURL' => 'easyterritoryurl',
  'LBL_EASYTERRITORYPROJECTID' => 'easyterritoryprojectid',
  'LBL_USERNAME' => 'EasyTerritory User Name',
  'LBL_EASYTERRITORYPASSWORD' => 'EasyTerritory Password',
  'LBL_LOCATIONLOOKUPSTREETFIELD' => 'Target Module Street Field Name',
  'LBL_LOCATIONLOOKUPCITYFIELD' => 'Target Module City Field Name',
  'LBL_LOCATIONLOOKUPSTATEFIELD' => 'Target Module State Field Name',
  'LBL_LOCATIONLOOKUPZIPFIELD' => 'Target Module Postal Code Field Name',
  'LBL_BINGKEY' => 'Bing Key',
  'LBL_TARGETMODULENAME' => 'Target Module Name',
  'LBL_MODULERELATIONSHIPNAME' => 'Module Relationship Link Name',
);