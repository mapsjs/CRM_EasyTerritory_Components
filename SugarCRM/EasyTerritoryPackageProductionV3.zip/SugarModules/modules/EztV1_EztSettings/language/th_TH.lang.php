<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/Resources/Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */
$mod_strings = array (
  'LBL_TEAM' => 'ทีม',
  'LBL_TEAMS' => 'ทีม',
  'LBL_TEAM_ID' => 'ID ทีม',
  'LBL_ASSIGNED_TO_ID' => 'ID ผู้ใช้ที่ระบุ',
  'LBL_ASSIGNED_TO_NAME' => 'ระบุให้',
  'LBL_TAGS_LINK' => 'แท็ก',
  'LBL_TAGS' => 'แท็ก',
  'LBL_ID' => 'ID',
  'LBL_DATE_ENTERED' => 'วันที่สร้าง',
  'LBL_DATE_MODIFIED' => 'วันที่แก้ไข',
  'LBL_MODIFIED' => 'แก้ไขโดย',
  'LBL_MODIFIED_ID' => 'แก้ไขโดย ID',
  'LBL_MODIFIED_NAME' => 'แก้ไขโดยชื่อ',
  'LBL_CREATED' => 'สร้างโดย',
  'LBL_CREATED_ID' => 'สร้างโดย ID',
  'LBL_DOC_OWNER' => 'เจ้าของเอกสาร',
  'LBL_USER_FAVORITES' => 'ผู้ใช้ที่เพิ่มรายการโปรด',
  'LBL_DESCRIPTION' => 'คำอธิบาย',
  'LBL_DELETED' => 'ลบ',
  'LBL_NAME' => 'ชื่อ',
  'LBL_CREATED_USER' => 'สร้างโดยผู้ใช้',
  'LBL_MODIFIED_USER' => 'แก้ไขโดยผู้ใช้',
  'LBL_LIST_NAME' => 'ชื่อ',
  'LBL_EDIT_BUTTON' => 'แก้ไข',
  'LBL_REMOVE' => 'นำออก',
  'LBL_EXPORT_MODIFIED_BY_NAME' => 'แก้ไขโดยชื่อ',
  'LBL_LIST_FORM_TITLE' => 'EasyTerritory Settings รายการ',
  'LBL_MODULE_NAME' => 'EasyTerritory Settings',
  'LBL_MODULE_TITLE' => 'EasyTerritory Settings',
  'LBL_MODULE_NAME_SINGULAR' => 'EasyTerritory Settings',
  'LBL_HOMEPAGE_TITLE' => 'ของฉัน EasyTerritory Settings',
  'LNK_NEW_RECORD' => 'สร้าง EasyTerritory Settings',
  'LNK_LIST' => 'มุมมอง EasyTerritory Settings',
  'LNK_IMPORT_EZTV1_EZTSETTINGS' => 'Import EasyTerritory Settings',
  'LBL_SEARCH_FORM_TITLE' => 'ค้นหา EasyTerritory Settings',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'ดูประวัติ',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'สตรีมกิจกรรม',
  'LBL_EZTV1_EZTSETTINGS_SUBPANEL_TITLE' => 'EasyTerritory Settings',
  'LBL_NEW_FORM_TITLE' => 'ใหม่ EasyTerritory Settings',
  'LNK_IMPORT_VCARD' => 'Import EasyTerritory Settings vCard',
  'LBL_IMPORT' => 'Import EasyTerritory Settings',
  'LBL_IMPORT_VCARDTEXT' => 'Automatically create a new EasyTerritory Settings record by importing a vCard from your file system.',
  'LBL_EASYTERRITORYURL' => 'easyterritoryurl',
  'LBL_EASYTERRITORYPROJECTID' => 'easyterritoryprojectid',
  'LBL_USERNAME' => 'EasyTerritory User Name',
  'LBL_EASYTERRITORYPASSWORD' => 'EasyTerritory Password',
  'LBL_LOCATIONLOOKUPSTREETFIELD' => 'Target Module Street Field Name',
  'LBL_LOCATIONLOOKUPCITYFIELD' => 'Target Module City Field Name',
  'LBL_LOCATIONLOOKUPSTATEFIELD' => 'Target Module State Field Name',
  'LBL_LOCATIONLOOKUPZIPFIELD' => 'Target Module Postal Code Field Name',
  'LBL_BINGKEY' => 'Bing Key',
  'LBL_TARGETMODULENAME' => 'Target Module Name',
  'LBL_MODULERELATIONSHIPNAME' => 'Module Relationship Link Name',
);