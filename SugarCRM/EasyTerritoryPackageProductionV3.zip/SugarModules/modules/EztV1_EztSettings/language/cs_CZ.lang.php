<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/Resources/Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */
$mod_strings = array (
  'LBL_TEAM' => 'Týmy',
  'LBL_TEAMS' => 'Týmy',
  'LBL_TEAM_ID' => 'ID týmu',
  'LBL_ASSIGNED_TO_ID' => 'Přiřazené uživateli s ID',
  'LBL_ASSIGNED_TO_NAME' => 'Přiřazeno komu',
  'LBL_TAGS_LINK' => 'Tagy',
  'LBL_TAGS' => 'Tagy',
  'LBL_ID' => 'ID',
  'LBL_DATE_ENTERED' => 'Datum zahájení',
  'LBL_DATE_MODIFIED' => 'Datum poslední úpravy',
  'LBL_MODIFIED' => 'Modifikováno kym',
  'LBL_MODIFIED_ID' => 'Upraveno podle ID',
  'LBL_MODIFIED_NAME' => 'Upraveno uživatelem',
  'LBL_CREATED' => 'Vytvořil:',
  'LBL_CREATED_ID' => 'Vytvořeno podle ID',
  'LBL_DOC_OWNER' => 'Vlastník dokumentu',
  'LBL_USER_FAVORITES' => 'Uživatelé, jejichž je oblíbeným',
  'LBL_DESCRIPTION' => 'Popis',
  'LBL_DELETED' => 'Odstranit',
  'LBL_NAME' => 'Název',
  'LBL_CREATED_USER' => 'Vytvořeno uživatelem',
  'LBL_MODIFIED_USER' => 'Změněno uživatelem',
  'LBL_LIST_NAME' => 'Název',
  'LBL_EDIT_BUTTON' => 'Editace',
  'LBL_REMOVE' => 'Odstranit',
  'LBL_EXPORT_MODIFIED_BY_NAME' => 'Upraveno uživatelem',
  'LBL_LIST_FORM_TITLE' => 'EasyTerritory Settings Celk. cena',
  'LBL_MODULE_NAME' => 'EasyTerritory Settings',
  'LBL_MODULE_TITLE' => 'EasyTerritory Settings',
  'LBL_MODULE_NAME_SINGULAR' => 'EasyTerritory Settings',
  'LBL_HOMEPAGE_TITLE' => 'Moje EasyTerritory Settings',
  'LNK_NEW_RECORD' => 'Přidat EasyTerritory Settings',
  'LNK_LIST' => 'Zobrazit EasyTerritory Settings',
  'LNK_IMPORT_EZTV1_EZTSETTINGS' => 'Import EasyTerritory Settings',
  'LBL_SEARCH_FORM_TITLE' => 'Hledat EasyTerritory Settings',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'Zobrazit historii',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Aktivity',
  'LBL_EZTV1_EZTSETTINGS_SUBPANEL_TITLE' => 'EasyTerritory Settings',
  'LBL_NEW_FORM_TITLE' => 'Nový EasyTerritory Settings',
  'LNK_IMPORT_VCARD' => 'Import EasyTerritory Settings vCard',
  'LBL_IMPORT' => 'Import EasyTerritory Settings',
  'LBL_IMPORT_VCARDTEXT' => 'Automatically create a new EasyTerritory Settings record by importing a vCard from your file system.',
  'LBL_EASYTERRITORYURL' => 'easyterritoryurl',
  'LBL_EASYTERRITORYPROJECTID' => 'easyterritoryprojectid',
  'LBL_USERNAME' => 'EasyTerritory User Name',
  'LBL_EASYTERRITORYPASSWORD' => 'EasyTerritory Password',
  'LBL_LOCATIONLOOKUPSTREETFIELD' => 'Target Module Street Field Name',
  'LBL_LOCATIONLOOKUPCITYFIELD' => 'Target Module City Field Name',
  'LBL_LOCATIONLOOKUPSTATEFIELD' => 'Target Module State Field Name',
  'LBL_LOCATIONLOOKUPZIPFIELD' => 'Target Module Postal Code Field Name',
  'LBL_BINGKEY' => 'Bing Key',
  'LBL_TARGETMODULENAME' => 'Target Module Name',
  'LBL_MODULERELATIONSHIPNAME' => 'Module Relationship Link Name',
);