<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/Resources/Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */
$mod_strings = array (
  'LBL_TEAM' => 'Teams',
  'LBL_TEAMS' => 'Teams',
  'LBL_TEAM_ID' => 'Team Id',
  'LBL_ASSIGNED_TO_ID' => 'Assigned User Id',
  'LBL_ASSIGNED_TO_NAME' => 'Assigned to',
  'LBL_TAGS_LINK' => 'Tags',
  'LBL_TAGS' => 'Tags',
  'LBL_ID' => 'ID',
  'LBL_DATE_ENTERED' => 'Date Created',
  'LBL_DATE_MODIFIED' => 'Date Modified',
  'LBL_MODIFIED' => 'Modified By',
  'LBL_MODIFIED_ID' => 'Modified By Id',
  'LBL_MODIFIED_NAME' => 'Modified By Name',
  'LBL_CREATED' => 'Created By',
  'LBL_CREATED_ID' => 'Created By Id',
  'LBL_DOC_OWNER' => 'Document Owner',
  'LBL_USER_FAVORITES' => 'Users Who Favorite',
  'LBL_DESCRIPTION' => 'Description',
  'LBL_DELETED' => 'Deleted',
  'LBL_NAME' => 'Name',
  'LBL_CREATED_USER' => 'Created by User',
  'LBL_MODIFIED_USER' => 'Modified by User',
  'LBL_LIST_NAME' => 'Name',
  'LBL_EDIT_BUTTON' => 'Edit',
  'LBL_REMOVE' => 'Remove',
  'LBL_EXPORT_MODIFIED_BY_NAME' => 'Modified By Name',
  'LBL_LIST_FORM_TITLE' => 'EasyTerritory Queue List',
  'LBL_MODULE_NAME' => 'EasyTerritory Queue',
  'LBL_MODULE_TITLE' => 'EasyTerritory Queue',
  'LBL_MODULE_NAME_SINGULAR' => 'EasyTerritory Queue',
  'LBL_HOMEPAGE_TITLE' => 'My EasyTerritory Queue',
  'LNK_NEW_RECORD' => 'Create EasyTerritory Queue',
  'LNK_LIST' => 'View EasyTerritory Queue',
  'LNK_IMPORT_EZTV1_EZTQUEUE' => 'Import EasyTerritory Queue',
  'LBL_SEARCH_FORM_TITLE' => 'Search EasyTerritory Queue',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'View History',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Activity Stream',
  'LBL_EZTV1_EZTQUEUE_SUBPANEL_TITLE' => 'EasyTerritory Queue',
  'LBL_NEW_FORM_TITLE' => 'New EasyTerritory Queue',
  'LNK_IMPORT_VCARD' => 'Import EasyTerritory Queue vCard',
  'LBL_IMPORT' => 'Import EasyTerritory Queue',
  'LBL_IMPORT_VCARDTEXT' => 'Automatically create a new EasyTerritory Queue record by importing a vCard from your file system.',
  'LBL_SUBMISSIONID' => 'Submission Id',
  'LBL_EZTUSERID' => 'Easy Territory User Id',
  'LBL_SUBMISSIONTYPE' => 'Submission Type',
  'LBL_SUBMISSIONINFO' => 'Submission Info',
  'LBL_MARKUPTAGVALUE' => 'Markup Tag Value',
  'LBL_RELATEDMODULEID' => 'Related Module Id',
  'LBL_RELATEDMODULENAME' => 'Related Module Name',
  'LBL_ASSIGNEDDATE' => 'Assigned Date',
  'LBL_RECORDVIEW_PANEL1' => 'New Panel 1',
);